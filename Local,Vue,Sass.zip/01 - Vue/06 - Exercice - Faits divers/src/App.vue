<template>
	<div id="my-app">
		<div v-bind:key="line" v-for="line in lines">- {{ line }}</div>
	</div>
</template>

<script>
export default {
	data () {
		return {
			lines : []
		}
	},
	methods: {
		addLine(line) {
			this.lines.push(line);
		}
	}
};
</script>
<style scoped>
	#my-app {
		width: 70vh;
		border:3px solid white;
		border-radius: 5px;
		margin:5vh auto;
		padding:5vh;
		color:white;
		font-size: 20px;
	}

	#my-app div {
		margin: 5px;
	}
</style>