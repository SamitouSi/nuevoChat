

const getFact = () => {
    fetch("https://meowfacts.herokuapp.com")
    .then(result => result.json())
    .then(result => {
        console.log(result["data"][0]);

        setTimeout(getFact, 20000);
    })
}

getFact();
