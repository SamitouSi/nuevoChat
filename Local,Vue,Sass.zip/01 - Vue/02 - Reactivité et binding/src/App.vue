<template>
	<div id="hero-app">
		<header>
			<input type="text" v-model="heroName" placeholder="Hero name" />
		</header>
		<div id="bubble">{{heroName}}, we are surrounded!</div>
		<img id="hero" src="img/hero.png" alt="heroes">
	</div>
</template>

<script>
	export default {

		data()
		{
			return
			{
				heroName : "Starfox" //crear una variable 
			}
		},

		methods:
		{	
			empyField : function ()
			{	
				this.heroName = ""
				
			},

			appendToName : function(txt)
			{
				this.heroName += txt
			}

		},



  	  	updated() {
			this.$nextTick(() => {
		  		console.log("Le component vient d'être modifié");
			});
		}
  	}
</script>
