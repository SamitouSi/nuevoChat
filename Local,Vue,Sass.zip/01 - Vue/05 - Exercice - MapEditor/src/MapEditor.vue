<template>
	<div id="map-editor-app">
		<header>
			<div class="flex">
				<div>
					<select>
						<option value="">- Choose background -</option>
						<option value="img/background1.jpg">Background 1</option>
						<option value="img/background2.jpg">Background 2</option>
						<option value="img/background3.jpg">Background 3</option>
					</select>
				</div>
				<div>
					<input type="text" placeholder="Map Name">
				</div>
				<div>
					Monstres : <button>+</button> <button>-</button>
				</div>
				<div>
					<button>Reset</button>
				</div>
			</div>
		</header>
		<div id="map" :style="{backgroundImage:'url(' + background + ')'}">
			<h1>{{ mapName }}</h1>
			<div>
				<div v-if="enemyCount > 0">
                    <img v-for="i in enemyCount" v-bind:key="i" src="img/enemy.png" :class="'enemy' + i" alt="enemy">
                </div>
			</div>
		</div>
	</div>
</template>

<script>
export default {
	name: "MapEditor",
	data() {
		return {
			background : "",
      		mapName: "",
			enemyCount : 0,
    	};
  	},
  	methods: {

  	},
};
</script>