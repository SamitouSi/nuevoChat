<template>
	<div id="hero-app">
		<div id="bubble">
			humm...
			<span v-if="monsters.length > 2">I believe we are surrounded !</span>
			<span v-else>This will be an easy win</span>
		</div>
		<img id="hero" src="img/hero.png" alt="heroes">

		<img v-for="monster in monsters" :src="monster.path" v-bind:key="monster.path" class="monster" :style="{left:monster.left,top : monster.top}" />
	</div>
</template>

<script>
	export default {
    	name : "App",
    	data() {
			return {
				monsters : [
					{
						path : "img/monster1.webp",
						left : "5vw",
						top : "15vh",
						life : 100
					},
					{
						path : "img/monster2.webp",
						left : "80vw",
						top : "40vh",
						life : 100
					},
					{
						path : "img/monster3.png",
						left : "80vw",
						top : "5vh",
						life : 100
					},
				]
			}
		}
	}
</script>