import Vue from 'vue'
import App from './App.vue'

new Vue({
	el: '#container',
	components: { App },
	template: '<App/>'
})