<template>
  	<div>
    	<h1>Hello there!</h1>
    	<p>General Kenobi</p>
		<Joke />
  	</div>
</template>

<script>
	import Joke from './Joke.vue';

  	export default {
		components : {
			Joke
		}
  	}
</script>

<style scoped>
	h1 {
    	color:blue;
  	}
</style>