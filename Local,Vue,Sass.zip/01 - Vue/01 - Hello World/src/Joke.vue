<template>
  	<div>
        <p>
            Q. What is the biggest lie in the entire universe?
        </p>
        <p>
            A. I have read and agree to the Terms &amp; Conditions.
        </p>
  	</div>
</template>

<style scoped>
	div {
        margin-top:50px;
    	font-style:italic;
  	}
</style>