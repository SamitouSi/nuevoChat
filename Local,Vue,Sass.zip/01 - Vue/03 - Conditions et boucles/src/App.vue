<template>
	<div id="hero-app">
    	<div id="bubble">
      		humm...
    		<span>I believe we are surrounded !</span>
    		<span>This will be an easy win</span>
		</div>
		<img id="hero" src="img/hero.png" alt="heroes">
	</div>
</template>

<script>
  	export default {
      	data() {
        	return {
				monsters : [
					{
						path : "img/monster1.webp",
						left : "5vw",
						top : "15vh",
						life : 100,
					},
					{
						path : "img/monster2.webp",
						left : "80vw",
						top : "40vh",
						life : 100,
					},
					{
						path : "img/monster3.png",
						left : "80vw",
						top : "5vh",
						life : 100,
					},
          		]
        	}
    	},
		methods :  {
			addMonster : function (left, top) {
				let newMonster = {
					path : "img/monster3.png",
					left : left + "vw",
					top : top + "vh"
				}

				this.monsters.push(newMonster);
			},
			hit(monster) {

			}
        }
	}
</script>