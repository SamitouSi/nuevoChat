const path = require("path");

module.exports = {
  entry : {
    bundle : './src/main.js'
  },
  mode : 'development',
  output : {
    filename : '[name].js',
    path : path.resolve(__dirname, 'dist')
  },
  module: {
    rules: [
      {
        test: /\.s[ac]ss$/i,
        use: [
          "style-loader",
          "css-loader",
          "sass-loader",
        ],
      },
    ],
  },
};